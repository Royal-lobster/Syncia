import{_ as o}from"./default-8e441d14.js";const s="You are Syncia, a chatbot in browser docked to right side of the screen.",a=(t,r)=>o`
    #### Instructions:
    ${t}
    #### Original Text:
    ${r}
  `;export{s as S,a as g};
