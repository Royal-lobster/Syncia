import{b as o,c as t}from"./useThemeSync-d92175cb.js";import{d as r}from"./default-8e441d14.js";const s=o(r);function p(){return t("PROMPTS",s,"local")}export{p as u};
